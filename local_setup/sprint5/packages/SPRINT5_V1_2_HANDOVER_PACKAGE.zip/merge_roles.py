import os, shutil, subprocess, zipfile
BASE="C:/Users/MI/.openmausbot/task-workspaces/5ccb6477-64f6-40a1-8d2f-9fa4ba5eb8f3/c36ce5b6-ee46-4765-9873-218ffad05481"
os.chdir(BASE)

# 1. MKT-01: prepend merge note into title line
p="MKT-01_Marketing_Strategist_template_v1_2.md"
s=open(p,encoding="utf-8").read()
if "Merged-in duties" not in s:
    s=s.replace("# MKT-01 | Marketing Strategist","# MKT-01 | Marketing Strategist (absorbs MKT-07 Marketing Performance Analyst)\n\n> **Merged-in duties (2026-11-24, per PM):** Marketing Performance Analyst responsibilities (KPI tracking, campaign performance reporting, channel/creative analysis, optimization recommendations) are now part of this role. Source: MKT-07 v1.2 file folded in; deep-merge of sections 3-11 to be reviewed.",1)
    open(p,"w",encoding="utf-8").write(s)

# 2. Create MKT-05 Sales Development Specialist by merging Lead Gen + Sales Assistant
lg=open("MKT-05_Lead_Generation_Specialist_template_v1_2.md",encoding="utf-8").read()
sa=open("MKT-06_Sales_Assistant_template_v1_2.md",encoding="utf-8").read()
merged="# MKT-05 | Sales Development Specialist (merger of Lead Generation Specialist + Sales Assistant)\n\n> **Merged (2026-11-24, per PM):** combines MKT-05 Lead Generation Specialist and MKT-06 Sales Assistant into one role. Sections below are concatenated from both source v1.2 files for reviewer deep-merge; treat the first block as Lead Gen duties, the second as Sales Assistant duties.\n\n===== PART A - LEAD GENERATION SPECIALIST (former MKT-05) =====\n\n"+lg+"\n\n===== PART B - SALES ASSISTANT (former MKT-06) =====\n\n"+sa
open("MKT-05_Sales_Development_Specialist_template_v1_2.md","w",encoding="utf-8").write(merged)

# 3. Remove redundant files
for f in ["MKT-06_Sales_Assistant_template_v1.md","MKT-06_Sales_Assistant_template_v1.docx","MKT-06_Sales_Assistant_template_v1_1.md","MKT-06_Sales_Assistant_template_v1_1.docx","MKT-06_Sales_Assistant_template_v1_2.md","MKT-06_Sales_Assistant_template_v1_2.docx","MKT-07_Marketing_Performance_Analyst_template_v1.md","MKT-07_Marketing_Performance_Analyst_template_v1.docx","MKT-07_Marketing_Performance_Analyst_template_v1_1.md","MKT-07_Marketing_Performance_Analyst_template_v1_1.docx","MKT-07_Marketing_Performance_Analyst_template_v1_2.md","MKT-07_Marketing_Performance_Analyst_template_v1_2.docx"]:
    if os.path.exists(f): os.remove(f)

# 4. Rebuild docx for changed/new files
for md in ["MKT-01_Marketing_Strategist_template_v1_2.md","MKT-05_Sales_Development_Specialist_template_v1_2.md"]:
    docx=md.replace(".md",".docx")
    subprocess.run(["python","build_docx.py",md,docx],check=True)
    print("built",docx)

# 5. Rebuild zip
zipname="SPRINT5_V1_2_HANDOVER_PACKAGE.zip"
files=[f for f in os.listdir(".") if f.endswith((".md",".docx",".py",".csv",".zip")) and not f.startswith("SPRINT5_V1_2_HANDOVER_PACKAGE")]
with zipfile.ZipFile(zipname,"w",zipfile.ZIP_DEFLATED) as z:
    for f in files:
        z.write(f)
print("zip rebuilt")
print("done")
