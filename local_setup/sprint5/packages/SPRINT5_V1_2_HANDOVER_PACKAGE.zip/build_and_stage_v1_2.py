from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

root = Path(r"C:\Users\MI\.openmausbot\task-workspaces\5ccb6477-64f6-40a1-8d2f-9fa4ba5eb8f3\c36ce5b6-ee46-4765-9873-218ffad05481")
handover = root / "sprint5_review_handover"
local = Path(r"C:\Users\MI\Documents\pegawai-ai-backend\local_setup\sprint5_review_handover")
local_templates = local / "role_templates_v1_2"
catalog_attachment = Path(r"C:\Users\MI\.openmausbot\attachments\c9cf124a-f3ae-4783-8edb-67c8ff3d2144.docx")
depth_attachment = Path(r"C:\Users\MI\.openmausbot\attachments\1b709b12-3688-4457-97c9-6fed408c9188.md")

local.mkdir(parents=True, exist_ok=True)
(local / "shared_page").mkdir(parents=True, exist_ok=True)
local_templates.mkdir(parents=True, exist_ok=True)

template_names = [
    "CS-01_Omnichannel_Customer_Service_template",
    "MKT-01_Marketing_Strategist_template",
    "MKT-02_SEO_Specialist_template",
    "MKT-03_Digital_Ads_Specialist_template",
    "MKT-04_Email_Marketing_Specialist_template",
    "MKT-05_Lead_Generation_Specialist_template",
    "MKT-06_Sales_Assistant_template",
    "MKT-07_Marketing_Performance_Analyst_template",
]
pairs = []
for name in template_names:
    pairs.append((root / f"{name}_v1_2.md", root / f"{name}_v1_2.docx"))
pairs += [
    (handover / "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_2.md", handover / "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_2.docx"),
    (handover / "SPRINT5_BE_FE_HANDOVER_v1_2.md", handover / "SPRINT5_BE_FE_HANDOVER_v1_2.docx"),
    (handover / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.md", handover / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx"),
]
for src, dst in pairs:
    subprocess.run([sys.executable, str(root / "build_docx.py"), str(src), str(dst)], check=True)

for src, dst in pairs[:8]:
    shutil.copy2(src, local_templates / src.name)
    shutil.copy2(dst, local_templates / dst.name)

for src, dst in pairs[8:]:
    shutil.copy2(src, local / src.name)
    shutil.copy2(dst, local / dst.name)

for name in [
    "SPRINT5_ROLE_TEMPLATE_SOURCE_REGISTER_v1_2.csv",
    "SPRINT5_SHARED_DOC_LINKS_v1_2.md",
]:
    shutil.copy2(handover / name, local / name)

shutil.copy2(catalog_attachment, local / "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx")
shutil.copy2(catalog_attachment, local / "shared_page" / "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx")
shutil.copy2(depth_attachment, local / "TEMPLATE_ROLE_DETAIL_11_MANDATORY_CHECKLIST.md")
shutil.copy2(depth_attachment, local / "SOURCE_TASK_PEGAWAI_AI_TEMPLATE_PROFILE_v1.md")
shutil.copy2(depth_attachment, handover / "TEMPLATE_ROLE_DETAIL_11_MANDATORY_CHECKLIST.md")
shutil.copy2(handover / "shared_page" / "index.html", local / "shared_page" / "index.html")

archive = root / "SPRINT5_V1_2_HANDOVER_PACKAGE.zip"
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(local_templates.glob("*")):
        zf.write(path, path.relative_to(local))
    for path in sorted(local.glob("SPRINT5_*_v1_2.*")):
        zf.write(path, path.name)
    zf.write(local / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.md", "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.md")
    zf.write(local / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx", "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx")
    zf.write(local / "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx", "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx")
    zf.write(local / "TEMPLATE_ROLE_DETAIL_11_MANDATORY_CHECKLIST.md", "TEMPLATE_ROLE_DETAIL_11_MANDATORY_CHECKLIST.md")
    zf.write(local / "SOURCE_TASK_PEGAWAI_AI_TEMPLATE_PROFILE_v1.md", "SOURCE_TASK_PEGAWAI_AI_TEMPLATE_PROFILE_v1.md")
    zf.write(local / "shared_page" / "index.html", "shared_page/index.html")

print("generated DOCX files:", len(pairs))
print("staged local handover:", local)
print("archive:", archive)
