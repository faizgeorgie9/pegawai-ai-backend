from pathlib import Path
import re
from docx import Document
import zipfile

root = Path(r"C:\Users\MI\.openmausbot\task-workspaces\5ccb6477-64f6-40a1-8d2f-9fa4ba5eb8f3\c36ce5b6-ee46-4765-9873-218ffad05481")
handover = root / "sprint5_review_handover"
local = Path(r"C:\Users\MI\Documents\pegawai-ai-backend\local_setup\sprint5_review_handover")
extracted = (root / "MASTER_CATALOG_EXTRACTED_v1.txt").read_text(encoding="utf-8").splitlines()

role_codes = ["CS-01", "MKT-01", "MKT-02", "MKT-03", "MKT-04", "MKT-05", "MKT-06", "MKT-07"]
files = {
    "CS-01": "CS-01_Omnichannel_Customer_Service_template_v1_1.docx",
    "MKT-01": "MKT-01_Marketing_Strategist_template_v1_1.docx",
    "MKT-02": "MKT-02_SEO_Specialist_template_v1_1.docx",
    "MKT-03": "MKT-03_Digital_Ads_Specialist_template_v1_1.docx",
    "MKT-04": "MKT-04_Email_Marketing_Specialist_template_v1_1.docx",
    "MKT-05": "MKT-05_Lead_Generation_Specialist_template_v1_1.docx",
    "MKT-06": "MKT-06_Sales_Assistant_template_v1_1.docx",
    "MKT-07": "MKT-07_Marketing_Performance_Analyst_template_v1_1.docx",
}
required_sections = [
    "1. Scope of Work & Boundaries",
    "2. Persona, Language & Tone of Voice",
    "3. Triggers & Use Cases",
    "4. Modular Skills & Capabilities",
    "5. SOP & Task Execution Pattern",
    "6. Operating Rules & Prohibitions",
    "7. Tools, Integrations & Permissions",
    "8. Knowledge Base & Memory Needs",
    "9. Input & Expected Output Standards",
    "10. Approval & Escalation Rules",
    "11. Model Recommendation & KPIs",
]

catalog = {}
for code in role_codes:
    idx = next(i for i, line in enumerate(extracted) if code + "  |  " in line)
    values = [extracted[idx].split("\t", 2)[2].strip()]
    j = idx + 1
    values.append(extracted[j].split("\t", 2)[2].strip())
    values.append(extracted[j + 2].split("\t", 2)[2].strip())
    values.append(extracted[j + 3].split("\t", 2)[2].strip())
    values.append(extracted[j + 4].split("\t", 2)[2].strip())
    catalog[code] = values

failures = []
for code in role_codes:
    doc = Document(root / files[code])
    text = "\n".join(p.text for p in doc.paragraphs)
    for expected in catalog[code]:
        if expected not in text:
            failures.append(f"{code}: missing catalog line {expected}")
    if "0. Catalog JD baseline (catalog supplied 2026-11-22)" not in text:
        failures.append(f"{code}: missing Section 0 heading")
    for section in required_sections:
        if section not in text:
            failures.append(f"{code}: missing {section}")
    for stale in ["Catalog JD baseline (source blocked)", "HTTP 403", "Blocker: the "]:
        if stale in text:
            failures.append(f"{code}: stale text {stale}")

packet = "\n".join(p.text for p in Document(handover / "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_1.docx").paragraphs)
packet_tables = "\n".join(c.text for t in Document(handover / "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_1.docx").tables for r in t.rows for c in r.cells)
packet_all = packet + "\n" + packet_tables
for expected in ["Sprint 5 Role Template Review Packet v1.1", "Master catalog JD baselines", "Local DOCX supplied 2026-11-22", "cross-check pending"]:
    if expected not in packet_all:
        failures.append("packet: missing " + expected)

be_fe_doc = Document(handover / "SPRINT5_BE_FE_HANDOVER_v1_1.docx")
be_fe = "\n".join(p.text for p in be_fe_doc.paragraphs) + "\n" + "\n".join(c.text for t in be_fe_doc.tables for r in t.rows for c in r.cells)
for expected in ["Sprint 5 Backend/Frontend Handover v1.1", "supplied catalog baseline", "version `v1.1`".replace("`", "")]:
    if expected not in be_fe:
        failures.append("handover: missing " + expected)

crosswalk_doc = Document(handover / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx")
crosswalk = "\n".join(p.text for p in crosswalk_doc.paragraphs)
for code in role_codes:
    if code not in crosswalk:
        failures.append("crosswalk: missing " + code)

expected_staged = [
    local / "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_1.docx",
    local / "SPRINT5_BE_FE_HANDOVER_v1_1.docx",
    local / "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx",
    local / "SPRINT5_ROLE_TEMPLATE_SOURCE_REGISTER_v1_1.csv",
    local / "SPRINT5_SHARED_DOC_LINKS_v1_1.md",
    local / "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx",
    local / "shared_page" / "index.html",
]
for path in expected_staged:
    if not path.exists():
        failures.append("missing staged file " + str(path))
for code, filename in files.items():
    if not (local / "role_templates_v1_1" / filename).exists():
        failures.append("missing staged template " + filename)

with zipfile.ZipFile(root / "SPRINT5_V1_1_HANDOVER_PACKAGE.zip") as zf:
    names = zf.namelist()
    for code, filename in files.items():
        if "role_templates_v1_1/" + filename not in names:
            failures.append("zip missing template " + filename)
    for required in [
        "SPRINT5_ROLE_TEMPLATE_REVIEW_PACKET_v1_1.docx",
        "SPRINT5_BE_FE_HANDOVER_v1_1.docx",
        "SPRINT5_CATALOG_BASELINE_CROSSWALK_v1.docx",
        "SPRINT5_ROLE_TEMPLATE_SOURCE_REGISTER_v1_1.csv",
        "SOURCE_AI_Top_Trends_Master_Catalog_30_Pegawai_AI_v1.0.docx",
        "shared_page/index.html",
    ]:
        if required not in names:
            failures.append("zip missing " + required)

print("catalog lines checked:", len(role_codes) * 5)
print("templates checked:", len(role_codes))
print("required sections per template:", len(required_sections))
print("failures:", len(failures))
for failure in failures:
    print(failure)
